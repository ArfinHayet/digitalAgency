const express = require('express');
const app = express();
const path = require('path');
const nodemailer = require('nodemailer');
var hbs = require('hbs');
const upload = require('express-fileupload');      
const { v4: uuidv4 } = require('uuid');
const async = require("async");
const cors = require('cors');
                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
const publicDirectory = path.join(__dirname);                              
app.use(express.static(publicDirectory));
console.log(publicDirectory);  

     
app.use(
  cors({
    origin: 'http://localhost:3000',
    credentials: true,
  })
);      
                                                                          
                                                                                                                                     
app.use(express.urlencoded({extended:false}));  
app.use(express.json());       
app.use(upload());        
                                                                        
                      
hbs.registerPartials(publicDirectory + '/views/partials');
                       
                                                              
app.use('/',require('./db.js'));
app.use('/',require('./routes/pages'));  
app.use('/',require('./routes/admin'));  
app.use(function(req, res, next) {
    res.status(404);
    res.send('<br><br><center><h1>Sorry! No page found.</h1></center>');
});
                                           
           
app.set('view engine','hbs');
                                 
                                                                                                                                       
           
app.listen(5000, ()=>{
	console.log("Server running 5000");              
});

             