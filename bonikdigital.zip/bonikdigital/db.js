const express = require('express');
const router = express.Router();


const mysql = require("mysql");
const db = mysql.createConnection({
	host : 'localhost',
	user : 'root',
	password : '',
	database : 'app'
});

db.connect((error)=>{
  if(error){
    console.log(error);
  } else {
    console.log('Connected');
  }
});


module.exports = router;