# jQuery carousel3d
============================
### Introduction
This plugin enables to create 3D carousel easily.


### Links
* [Demo](http://kabocha.orz.hm/labo/carousel3d/demo/)
* [Documents](http://kabocha.orz.hm/labo/carousel3d/docs/)


### Requirements
* jQuery-1.7.2+
* jQuery-ui-1.10.0+(depend on Widget Module)


### Compatibility
* Internet Explorer 11+
* Firefox
* Chrome
* Safari
* Mobile Safari
* Android Chrome

※ We support only latest version of Firefox/Chrome/Safari/Opera. 


### License
Copyright (c) 2014 thujikun
Licensed under the [MIT license](https://github.com/thujikun/jquery-carousel3d/blob/master/LICENSE_MIT).
