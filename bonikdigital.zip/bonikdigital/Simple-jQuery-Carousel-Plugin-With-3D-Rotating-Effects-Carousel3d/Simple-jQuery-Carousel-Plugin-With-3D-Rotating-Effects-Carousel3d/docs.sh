jsduck jquery-carousel3d-1.0.0.js --out docs/ --title "carousel3d Documents"
