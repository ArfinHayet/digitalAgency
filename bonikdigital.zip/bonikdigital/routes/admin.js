const express = require('express');
const router = express.Router();
const upload = require('express-fileupload');
const { v4: uuidv4 } = require('uuid');
const app = express();


const mysql = require("mysql");
const db = mysql.createConnection({
  host : 'localhost',
  user : 'root',
  password : '',
  database : 'app'
});

db.connect((error)=>{
  if(error){
    console.log(error);
  } else {
    console.log('Connected');
  }
});



router.get('/digital/admin',(req,res)=>{
  res.render("home");
});

router.get("/admin/fileupload",(req,res)=>{
  res.render("fileupload");
});

router.get("/digital/admin/adservice",(req,res)=>{
  db.query("SELECT *FROM service",(err,results)=>{
    res.render("addservice",{
      opt : results,
    });
  })
});




router.post("/digital/admin/adservice",(req,res)=>{
  const {sid,name,price,des} = req.body;

  db.query("INSERT INTO package SET ?",{sid:sid,name:name,price:price,des:des},(err,results)=>{
    if(err){
      console.log(err);
    } else {
      res.redirect("/digital/admin/feature/" + results.insertId);
    }
  })
})



router.get("/digital/admin/feature/:id/",(req,res)=>{
  var id = req.params.id;
  console.log(id);
  res.render("feature",{
    data : id,
  });
})

router.post("/digital/admin/feature/",(req,res)=>{
  const {id,val} = req.body;
  res.send(val);
  db.query("INSERT INTO feature SET ?",{feature:val,pid:id},(err,results)=>{
    if(err){
      console.log(err);
    }
  })
})






router.post("/admin/upload",(req,res)=>{

           
  const { section, service, des } = req.body;
  console.log(req.body);
  
  var file = req.files.foo;
  var filename = uuidv4() + file.name;
  
  file.mv('./image/' +filename,(err)=>{
    if(err){
      console.log(err);
    } else {
      console.log('File Upload');
    }
  })

  db.query("INSERT INTO service SET ?", {section:section,service:service,image:filename,description:des},(err)=>{
    if(err){
      console.log(err);
    } else {
      res.render('fileupload',{
        message : "Data Inserted",
      })
      console.log('Data Inserted');
    }
  })
 
});

module.exports = router;