const express = require('express');
const router = express.Router();
const nodemailer = require('nodemailer');
const upload = require('express-fileupload');
const { v4: uuidv4 } = require('uuid');
const async = require("async");


const mysql = require("mysql");
const db = mysql.createConnection({
  host : 'localhost',
  user : 'root',
  password : '',
  database : 'app'
});

db.connect((error)=>{
  if(error){
    console.log(error);
  } else {
    console.log('Connected');
  }
});


router.get("/chat",(req,res)=>{
  res.render("chat");
})

router.get("/digital",(req,res)=>{
 
     db.query("SELECT *FROM service WHERE section=?",['Development'],(err,results)=>{
        db.query("SELECT *FROM service WHERE section=?",['Advertisement'],(err,results2)=>{
          db.query("SELECT *FROM service WHERE section=?",['Content'],(err,results3)=>{
            db.query("SELECT *FROM service WHERE section=?",["Design"],(err,results4)=>{
                res.render('index',{
                dev: results,
                add: results2,
                con: results3,
              })
            })
          })
        })
     })
      
  });



  router.get("/digital/service/:id",(req,res)=>{
  var id = req.params.id;
  db.query("SELECT *FROM service WHERE id=?",[id],(err,results)=>{
    if(err){
      res.rend("Sorry! No result found.");
      console.log(err);
    } else {    
      db.query("SELECT *FROM package WHERE sid=?",[id],(err,results2)=>{
                res.render('service',{
                row : results,
                pac : results2,             
               });           
          
      })
    }
  })
})
 

router.get("/digital/boost",(req,res)=>{
  res.render("boost");
})

router.get("/digital/contact",(req,res)=>{
	res.render("contact");
});

router.get("/digital/sendMail",(req,res)=>{
   sendMail();
   res.redirect("/");
});

router.get("/digital/projects",(req,res)=>{
  res.render("project");
})

router.post("/digital/mail", (req,res)=>{

     const { email,message } = req.body;
     sendMail(res,email,message);
});

router.post("/arfin",(req,res)=>{
     const { email,message } = req.body;
     console.log(email);
     res.json(
      [{
      'name': 'arfin',
      'type': 'boss',
     },
     {
      'name': 'shit',
      'type': 'popo',
     }]
     );
});  

router.post("/digital/fetch", (req,res)=>{
    res.send('<b>Works</b>');
});

router.post("/digital/service/fetch",(req,res)=>{
  const {id} = req.body;
  
  db.query("SELECT *FROM feature WHERE pid=?",[id],(err,results)=>{
      results.forEach(element => { 
        res.write('<li class="list-group-item list-group-item-action flush">'+element.feature+'</li>'); 
      });

      res.end();
  })
})








function sendMail(res,email,message){
   let transporter = nodemailer.createTransport({
    host: 'mail.bonikapp.com',
    port: 465,
    secure: true, // true for 465, false for other ports
    auth: {
        user: 'arfin@bonikapp.com', // generated ethereal user
        pass: '#5431879abc@SNIPERviper$'  // generated ethereal password
    },
    tls:{
      rejectUnauthorized:false
    }
  });

  // setup email data with unicode symbols
  let mailOptions = {
      from: '"Bonik Digital" <arfin@bonikapp.com>', // sender address
      to: 'mybonikapp@gmail.com', // list of receivers
      subject: 'Bonik Digital Contact', // Subject line
      text: email + ' | ' + message, // plain text body
      
  };

  // send mail with defined transport object
  transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
          return console.log(error);
      }
      console.log('Message sent: %s', info.messageId);   
      console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));

      res.render('contact', {message:'Email has been sent'});
  });

}

module.exports = router;
