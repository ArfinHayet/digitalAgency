const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  
   service : 'gmail',
   secure: false, 
   port: 25,
    auth : {
    	user : 'Arfinhayet2@gmail.com',
    	pass : '#5431879abc@SNIPERviper$',
    },

    tls : {
    	rejectUnauthorized:false
    }
});


const mailOptions = {
	from : 'Arfinhayet786@gmail.com',
	to : 'mybonikapp@gmail.com',
	subject : 'Node.js Automated email testing',
	text : 'Testing testing arfin arfin'
}

transporter.sendMail(mailOptions,(error,info)=>{
   if(error){
   	console.log(error);
   } else {
   	console.log(info.response);
   }
});